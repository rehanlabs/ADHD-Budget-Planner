================================================================
ADHD BUDGET PLANNER � 100% OFFLINE STANDALONE EDITION
================================================================

HOW TO USE ON MAC OR WINDOWS:
1. Double-click "index.html" to open the planner in your browser.
2. It runs 100% locally directly from your hard drive.
3. Zero internet connection required!
4. Your data is stored privately on your computer.

MONTHLY BACKUP RECOMMENDATION:
Click Settings (gear icon) -> "Download Backup (.json)" once a month
to save a local backup copy of your financial data.

Need help? Message us directly on Etsy anytime! ??
